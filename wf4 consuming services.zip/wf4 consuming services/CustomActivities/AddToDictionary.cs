﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace CustomActivities
{

    public sealed class AddToDictionary<TKey,TValue> : CodeActivity
    {
        
        public InArgument<TValue> Value { get; set; }
        public InArgument<TKey> Key { get; set; }
        public InArgument<Dictionary<TKey,TValue>> Dictionary { get; set; }

        
        protected override void Execute(CodeActivityContext context)
        {
            TKey k = Key.Get(context);
            TValue v = Value.Get(context);
            Dictionary<TKey, TValue> dict = Dictionary.Get(context);

            if (dict != null)
            {
                dict[k] = v;
            }
        }
    }
}
