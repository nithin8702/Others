﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCFClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var client =
                new ExpenseService.ExpenseServiceClient();

            Console.WriteLine("Submitting report");

            var confirmation = client.SubmitReport(
                new ExpenseService.ExpenseReport
                {
                    Amount = 250,
                    Client = "Pluralsight",
                    City = "Austin, TX",
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddDays(2),
                    Employee = new ExpenseService.Person
                    {
                        Name = "Matt",
                        Email = "matt@pluralsight.com"
                    }
                });

            Console.WriteLine("Confirmation received for report {0}", confirmation.ReportID);
            Console.WriteLine("Submitting manager response");

            client.SubmitManagerResponse(
                new ExpenseService.ManagerResponse
                {
                    ItemIdentifier = confirmation.ReportID,
                    ManagerName = "Bob",
                    Approved = true
                });

            Console.WriteLine("Manager response accepted");
            client.Close();
            Console.ReadLine();
        }
    }
}
