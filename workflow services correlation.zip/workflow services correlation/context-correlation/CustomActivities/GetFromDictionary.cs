﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace CustomActivities
{

    public sealed class GetFromDictionary<TKey, TValue> : CodeActivity<TValue>
    {
        public InArgument<TKey> Key { get; set; }
        public InArgument<Dictionary<TKey, TValue>> Dictionary { get; set; }


        protected override TValue Execute(CodeActivityContext context)
        {
            TKey k = Key.Get(context);
            
            Dictionary<TKey, TValue> dict = Dictionary.Get(context);

            if (dict != null)
            {
                if (dict.ContainsKey(k))
                    return dict[k];
            }
            
            return default(TValue);
        }
    }
}
