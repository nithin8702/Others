﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace CustomActivities
{

    public sealed class WriteToEventLog : CodeActivity
    {
        // Define an activity input argument of type string
        public InArgument<string> Text { get; set; }
        public InArgument<string> LogName { get; set; }
        

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override void Execute(CodeActivityContext context)
        {
            System.Diagnostics.EventLog.WriteEntry("WF4 Application", Text.Get(context), System.Diagnostics.EventLogEntryType.Error);

        }
    }
}
