﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.ServiceModel.Activities;

namespace WFClient
{

    class Program
    {
        static void Main(string[] args)
        {
            var invoker = new WorkflowInvoker(
                new Workflow1());
            //invoker.Extensions.Add(
            //    new SendMessageChannelCache
            //    {
            //        AllowUnsafeCaching = true,
            //        ChannelSettings = new ChannelCacheSettings { MaxItemsInCache = 5, LeaseTimeout=TimeSpan.FromMinutes(1), IdleTimeout = TimeSpan.FromMinutes(1) },
            //        FactorySettings = new ChannelCacheSettings { MaxItemsInCache = 5, LeaseTimeout = TimeSpan.FromMinutes(1), IdleTimeout = TimeSpan.FromMinutes(1) }
            //    });
            invoker.Invoke();
            Console.WriteLine("Done");
            Console.ReadLine();
        }
    }
}
