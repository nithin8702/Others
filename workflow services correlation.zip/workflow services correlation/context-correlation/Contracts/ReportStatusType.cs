﻿public enum ReportStatusType
{
    Submitted,
    Approved,
    Rejected
}