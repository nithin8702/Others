﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.ServiceModel.Activities;
using System.Threading;

namespace WFClient
{

    class Program
    {
        static void Main(string[] args)
        {
            ManualResetEventSlim waitHandle =
                new ManualResetEventSlim(false);
            
            //*** Workflow 1 with messaging activities **/
            var invoker = new WorkflowApplication(
                new Workflow2());

            //*** Workflow 2 with ASR **/
            //var invoker = new WorkflowApplication(
            //   new Workflow2());

            //*** Workflow 3 with channel cache **/
            //var cache = new SendMessageChannelCache
            //    (
            //       new ChannelCacheSettings { 
            //           MaxItemsInCache = 5, 
            //           LeaseTimeout = TimeSpan.FromMinutes(1), 
            //           IdleTimeout = TimeSpan.FromMinutes(1) },
            //        new ChannelCacheSettings { 
            //            MaxItemsInCache = 5, 
            //            LeaseTimeout = TimeSpan.FromMinutes(1), 
            //            IdleTimeout = TimeSpan.FromMinutes(1) },
            //        true
            //    );

            //var invoker = new WorkflowApplication(
            //    new Workflow3());
            //invoker.Extensions.Add(cache);

            invoker.Completed += (e) =>
                {
                    waitHandle.Set();
                };

            invoker.Run();

            waitHandle.Wait();
            Console.WriteLine("Done");
            Console.ReadLine();
        }
    }
}
