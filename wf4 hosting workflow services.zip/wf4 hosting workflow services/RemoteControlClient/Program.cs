﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activities;
using System.ServiceModel;

namespace RemoteControlClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Guid wfid = new Guid(args[0]);

            WorkflowControlClient client =
                new WorkflowControlClient(
                    new WorkflowControlEndpoint(
                        new BasicHttpBinding(), 
                        new EndpointAddress(
                            "http://localhost:30468/Service1.xamlx/Control")));
            client.Unsuspend(wfid);
           
            client.Close();

        }
    }
}
