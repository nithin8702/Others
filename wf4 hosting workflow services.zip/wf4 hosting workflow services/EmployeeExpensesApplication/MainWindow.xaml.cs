﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeExpensesApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Expenses.ExpenseReport report;
        Expenses.ExpenseReportConfirmation confirm;


        public MainWindow()
        {
            InitializeComponent();
            report = new Expenses.ExpenseReport();
            report.Employee = new Expenses.Person();
            report.StartDate = DateTime.Now;
            report.EndDate = DateTime.Now;

            DataContext = report;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Expenses.ExpenseServiceClient client = new Expenses.ExpenseServiceClient();
            confirm = client.SubmitReport(report);
            DataContext = confirm;
        }
    }
}
