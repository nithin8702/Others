﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Contracts
{
    [DataContract]
    public class ExpenseReportConfirmation : ExpenseReport
    {
        [DataMember]
        public int ReportID { get; set; }

        [DataMember]
        public ReportStatusType Status { get; set; }
    }
}
