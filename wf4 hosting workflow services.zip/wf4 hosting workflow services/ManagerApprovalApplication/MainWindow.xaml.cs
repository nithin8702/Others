﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ManagerApprovalApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Expenses.ManagerResponse response;
        public MainWindow()
        {
            InitializeComponent();
            response = new Expenses.ManagerResponse();
            DataContext = response;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Expenses.ExpenseServiceClient client =
                new Expenses.ExpenseServiceClient();
            try
            {
                client.SubmitManagerResponse(response);
                MessageBox.Show("Your response has been submitted");
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error submitting your request");
            }
           
        }
    }
}
